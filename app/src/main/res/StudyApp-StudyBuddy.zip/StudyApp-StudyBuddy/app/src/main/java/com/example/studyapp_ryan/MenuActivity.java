package com.example.studyapp_ryan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import android.content.Intent;


import android.view.View;
import android.widget.ImageButton;


import com.google.firebase.auth.FirebaseAuth;


public class MenuActivity extends AppCompatActivity {
    CardView goalCard;
    CardView dictionaryCard;
    CardView quizCard;
    CardView timerCard;
    ImageButton logout_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        goalCard = findViewById(R.id.goalCard);
        goalCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        dictionaryCard = findViewById(R.id.dictionaryCard);
        dictionaryCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, DictionaryActivity.class);
                startActivity(intent);
            }
        });
        quizCard = findViewById(R.id.quizCard);
        quizCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, DictionaryActivity.class);
                startActivity(intent);
            }
        });
        timerCard = findViewById(R.id.timerCard);
        timerCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, DictionaryActivity.class);
                startActivity(intent);
            }
        });



    }

    void showMenu() {
        logout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Sign out from Firebase
                FirebaseAuth.getInstance().signOut();

                // Start the LoginActivity
                startActivity(new Intent(MenuActivity.this, LoginActivity.class));

                // Finish the current MenuActivity
                finish();
            }
        });
    }
}